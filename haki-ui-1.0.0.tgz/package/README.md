# haki-ui

Dark-themed React UI components powered by CSS variables and Tailwind utility classes.

## Install

```bash
npm install haki-ui
```

Also install peer dependencies if your app does not already have them:

```bash
npm install react react-dom lucide-react
```

## Quick usage

```tsx
import { HakiProvider, Button, Input } from "haki-ui";

export default function App() {
  return (
    <HakiProvider>
      <div className="p-6 space-y-4 bg-black min-h-screen">
        <Input placeholder="Email address" />
        <Button variant="solid">Continue</Button>
      </div>
    </HakiProvider>
  );
}
```

## Styling note

This package uses Tailwind-style utility classes in component markup. Ensure your app includes compatible utility CSS (for example, Tailwind CSS) so those classes render correctly.

## Exported API

- `HakiProvider`, `useTheme`, `defaultTheme`
- `hexToRgb`, `getRadiusStyle`
- `Button`, `Input`, `Modal`, `Pagination`, `Switch`, `Tooltip`
- `Table`, `TableHeader`, `TableColumn`, `TableBody`, `TableRow`, `TableCell`
- `Tabs`, `Accordion`, `AccordionItem`, `Checkbox`, `Radio`, `Calendar`

## Publish (maintainer)

```bash
npm login
npm run build
npm publish --access public
```
